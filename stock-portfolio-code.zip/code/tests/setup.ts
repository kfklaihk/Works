import { expect, afterEach, vi } from 'vitest';
import { cleanup } from '@testing-library/react';
import '@testing-library/jest-dom/vitest';

// Cleanup after each test
afterEach(() => {
  cleanup();
});

// Mock environment variables
process.env.VITE_SUPABASE_URL = 'https://test.supabase.co';
process.env.VITE_SUPABASE_ANON_KEY = 'test-anon-key';
process.env.VITE_MARKETSTACK_API_KEY = '4b07745ad79b66dfd320697e5e40f596';
process.env.VITE_DEEPSEEK_API_KEY = 'test-deepseek-key';
