#!/bin/bash

echo "========================================================="
echo "  Push to GitHub: kfklaihk/modernize_legacy"
echo "========================================================="
echo ""

# Check if repository exists
echo "Checking if repository exists..."
if ! gh repo view kfklaihk/modernize_legacy &>/dev/null; then
    echo ""
    echo "❌ Repository 'kfklaihk/modernize_legacy' does not exist yet!"
    echo ""
    echo "Please create it first:"
    echo ""
    echo "1. Go to: https://github.com/new"
    echo "2. Repository name: modernize_legacy"
    echo "3. Description: Application Modernization - Legacy ASP.NET to React + Supabase"
    echo "4. Make it Public (recommended)"
    echo "5. ⚠️  Do NOT check 'Initialize with README'"
    echo "6. Click 'Create repository'"
    echo ""
    echo "After creating the repository, run this script again."
    echo ""
    exit 1
fi

echo "✅ Repository exists!"
echo ""

# Add remote
echo "Configuring git remote..."
git remote remove origin 2>/dev/null || true
git remote add origin https://github.com/kfklaihk/modernize_legacy.git

echo "✅ Remote configured!"
echo ""

# Push to GitHub
echo "Pushing to GitHub..."
echo ""

git push -u origin main

if [ $? -eq 0 ]; then
    echo ""
    echo "========================================================="
    echo "  ✅ SUCCESS! Repository pushed to GitHub!"
    echo "========================================================="
    echo ""
    echo "🎉 Your repository is now live at:"
    echo "   https://github.com/kfklaihk/modernize_legacy"
    echo ""
    echo "📝 Next steps:"
    echo ""
    echo "1. Deploy to Vercel:"
    echo "   cd code"
    echo "   ./deploy-to-vercel.sh"
    echo ""
    echo "2. Or deploy via Vercel website:"
    echo "   - Go to https://vercel.com"
    echo "   - Import the modernize_legacy repository"
    echo "   - See VERCEL_DEPLOYMENT_GUIDE.md for details"
    echo ""
else
    echo ""
    echo "❌ Push failed!"
    echo ""
    echo "Possible solutions:"
    echo ""
    echo "1. Authenticate with GitHub CLI:"
    echo "   gh auth login"
    echo "   Then run this script again"
    echo ""
    echo "2. Or use SSH:"
    echo "   git remote set-url origin git@github.com:kfklaihk/modernize_legacy.git"
    echo "   git push -u origin main"
    echo ""
    echo "3. Or use personal access token:"
    echo "   - Go to: https://github.com/settings/tokens"
    echo "   - Generate new token with 'repo' scope"
    echo "   - Use token as password when prompted"
    echo ""
fi
