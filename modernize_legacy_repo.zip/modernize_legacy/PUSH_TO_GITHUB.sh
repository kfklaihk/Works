#!/bin/bash
echo "========================================================"
echo "  Deploy to GitHub: kfklaihk/modernize_legacy"
echo "========================================================"
echo ""
echo "Checking repository..."
if ! gh repo view kfklaihk/modernize_legacy &>/dev/null; then
    echo "❌ Repository doesn't exist. Create it at: https://github.com/new"
    echo "   Name: modernize_legacy"
    echo "   Don't initialize with README"
    exit 1
fi
echo "✅ Repository exists"
echo ""
git remote remove origin 2>/dev/null || true
git remote add origin https://github.com/kfklaihk/modernize_legacy.git
echo "Pushing to GitHub..."
git push -u origin main
if [ $? -eq 0 ]; then
    echo ""
    echo "✅ SUCCESS! View at: https://github.com/kfklaihk/modernize_legacy"
    echo ""
    echo "Next: Deploy to Vercel"
    echo "  cd code && ./deploy-to-vercel.sh"
else
    echo "❌ Push failed. Try: gh auth login"
fi
