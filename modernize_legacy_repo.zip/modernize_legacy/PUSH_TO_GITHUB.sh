#!/bin/bash

echo "======================================"
echo "Push to modernize_legacy Repository"
echo "======================================"
echo ""

# Check if repository exists
echo "Checking if repository kfklaihk/modernize_legacy exists..."
if ! gh repo view kfklaihk/modernize_legacy &>/dev/null; then
    echo ""
    echo "❌ Repository does not exist yet!"
    echo ""
    echo "Please create it first:"
    echo "1. Go to: https://github.com/new"
    echo "2. Repository name: modernize_legacy"
    echo "3. Description: Application Modernization Plan - Legacy ASP.NET MVC to .NET 8 + React + Supabase"
    echo "4. Make it Public (or Private)"
    echo "5. Do NOT initialize with README, .gitignore, or license"
    echo "6. Click 'Create repository'"
    echo ""
    echo "After creating, run this script again."
    exit 1
fi

echo "✅ Repository exists!"
echo ""

# Add remote
echo "Adding remote origin..."
git remote remove origin 2>/dev/null || true
git remote add origin https://github.com/kfklaihk/modernize_legacy.git

echo "✅ Remote added!"
echo ""

# Push to GitHub
echo "Pushing to GitHub..."
git push -u origin main

if [ $? -eq 0 ]; then
    echo ""
    echo "======================================"
    echo "✅ SUCCESS! Repository pushed!"
    echo "======================================"
    echo ""
    echo "View your repository at:"
    echo "https://github.com/kfklaihk/modernize_legacy"
    echo ""
    echo "Next steps:"
    echo "1. Go to the code/ directory"
    echo "2. Run: npm install"
    echo "3. Configure .env file"
    echo "4. Run: npm run dev"
    echo "5. Run: npm test (to verify everything works)"
    echo ""
else
    echo ""
    echo "❌ Push failed. You may need to authenticate."
    echo ""
    echo "Try running:"
    echo "  gh auth login"
    echo ""
    echo "Or use SSH instead:"
    echo "  git remote set-url origin git@github.com:kfklaihk/modernize_legacy.git"
    echo "  git push -u origin main"
fi
